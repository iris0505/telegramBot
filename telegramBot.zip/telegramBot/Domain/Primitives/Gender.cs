namespace Domain.Primitives;

public enum Gender {
    Undefined = 0,
    Man = 1,
    Woman = 2,
}